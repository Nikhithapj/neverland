package com.example.library.service.Impl;

import com.example.library.dto.CustomerDto;
import com.example.library.model.Customer;
import com.example.library.repository.CustomerRepository;
import com.example.library.repository.RoleRepository;
import com.example.library.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {
    private final CustomerRepository customerRepository;
    private final RoleRepository roleRepository;



    @Override
    public Customer save(CustomerDto customerDto) {
        Customer customer = new Customer();
        customer.setFirstName(customerDto.getFirstName());
        customer.setLastName(customerDto.getLastName());
        customer.setPassword(customerDto.getPassword());
        customer.setUsername(customerDto.getUsername());
        customer.setRoles(Arrays.asList(roleRepository.findByName("CUSTOMER")));
        return customerRepository.save(customer);
    }

    @Override
    public Customer findByUsername(String username) {
        return customerRepository.findByUsername(username);
    }


    //code written by you additionally
//    public Customer findById(int id)
//    {
//        return customerRepository.findById( int id);
//    }


    @Override
    public CustomerDto getCustomer(String username) {
        CustomerDto customerDto = new CustomerDto();
        Customer customer = customerRepository.findByUsername(username);
        customerDto.setFirstName(customer.getFirstName());
        customerDto.setLastName(customer.getLastName());
        customerDto.setUsername(customer.getUsername());
        customerDto.setPassword(customer.getPassword());
        customerDto.setAddress(customer.getAddress());
        customerDto.setPhoneNumber(customer.getPhoneNumber());
//        customerDto.setCity(customer.getCity());
//        customerDto.setCountry(customer.getCountry());
        return customerDto;
    }

    @Override
    public Customer changePass(CustomerDto customerDto) {
        Customer customer = customerRepository.findByUsername(customerDto.getUsername());
        customer.setPassword(customerDto.getPassword());
        return customerRepository.save(customer);
    }

    @Override
    public Customer update(CustomerDto dto) {
        Customer customer = customerRepository.findByUsername(dto.getUsername());
        customer.setAddress(dto.getAddress());
//        customer.setCity(dto.getCity());
//        customer.setCountry(dto.getCountry());
        customer.setPhoneNumber(dto.getPhoneNumber());
        return customerRepository.save(customer);
    }

    @Override
    public List<CustomerDto> findAll()  {
        List<CustomerDto>  customerDtoList = new ArrayList<>();
        List<Customer> customers = (List<Customer>) customerRepository.findAll();
        for(Customer customer:customers){
            CustomerDto customerDto = new CustomerDto();
            customerDto.setId(customer.getId());
            customerDto.setFirstName(customer.getFirstName());
            customerDto.setLastName(customer.getLastName());
            customerDto.setUsername(customer.getUsername());
            customerDto.setPhoneNumber(customer.getPhoneNumber());
            customerDto.setBlocked(customer.is_blocked());
            customerDtoList.add(customerDto);
        }
        return customerDtoList;
    }

//    @Override
//    public void blockUser(Long id) {
//        Customer customer = customerRepository.getReferenceById(id);
//        if (customer.is_blocked()){
//            customer.set_blocked(false);
//        }
//        else {
//            customer.set_blocked(true);
//        }
//        customerRepository.save(customer);
//
//
//    }

  public void blockById(Long id){
        Customer customer=customerRepository.getReferenceById(id);
        customer.set_blocked(true);
        customerRepository.save(customer);
  }

    public void unblockById(Long id){
        Customer customer=customerRepository.getReferenceById(id);
        customer.set_blocked(false);
        customerRepository.save(customer);
    }




}
