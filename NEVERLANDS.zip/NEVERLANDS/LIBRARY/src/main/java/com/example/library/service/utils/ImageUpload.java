package com.example.library.service.utils;


import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Component
public class ImageUpload {
    private final String UPLOAD_FOLDER = "C:\\Users\\USER\\Downloads\\KidsArt-Ecommerce-Springboot (2)\\NEVERLANDS\\ADMIN\\src\\main\\resources\\static\\imgs\\image-product";

//    C:\Users\USER\Downloads\KidsArt-Ecommerce-Springboot (2)\NEVERLANDS.zip\NEVERLANDS\ADMIN\src\main\resources\static\imgs\image-product
    public boolean uploadFile(MultipartFile file) {
        boolean isUpload = false;
        try {
            Files.copy(file.getInputStream(), Paths.get(UPLOAD_FOLDER + File.separator + file.getOriginalFilename()) , StandardCopyOption.REPLACE_EXISTING);
//            C:\Users\USER\Downloads\KidsArt-Ecommerce-Springboot (2)\NEVERLANDS\CUSTOMER\src\main\resources\static\imgs\banner\banner-1.png
            isUpload = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isUpload;
    }

    public boolean checkExist(MultipartFile multipartFile){
        boolean isExist = false;
        try {
            File file = new File(UPLOAD_FOLDER +"\\" + multipartFile.getOriginalFilename());
            isExist = file.exists();
        }catch (Exception e){
            e.printStackTrace();
        }
        return isExist;
    }
}
