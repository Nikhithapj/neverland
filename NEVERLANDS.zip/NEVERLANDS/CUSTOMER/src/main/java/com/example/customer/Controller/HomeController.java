package com.example.customer.Controller;


//import com.example.library.model.Customer;
//import com.example.library.model.ShoppingCart;
import com.example.customer.config.CustomerDetails;
import com.example.library.dto.ProductDto;
import com.example.library.model.Customer;
import com.example.library.repository.CustomerRepository;
import com.example.library.service.CategoryService;
import com.example.library.service.CustomerService;
import com.example.library.service.ProductService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.List;
@Controller
@RequiredArgsConstructor
public class HomeController {

    private CustomerService customerService;
    private ProductService productService;
    private CategoryService categoryService;
    private  CustomerRepository customerRepository;
    public HomeController(CustomerService customerService, ProductService productService, CategoryService categoryService,CustomerRepository customerRepository) {
        this.customerService = customerService;
        this.productService = productService;
        this.categoryService = categoryService;
        this.customerRepository =customerRepository;

    }
    CustomerDetails  customerDetails;
    @RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
    public String home(Model model, Principal principal, HttpSession session) {
//        if (principal == null) {
//            return "redirect:/login";
//        } else {
//            Customer customer = customerService.findByUsername(principal.getName());
//            session.setAttribute("userLoggedIn", true);
//            session.setAttribute("username", customer.getFirstName() + " " + customer.getLastName());
            model.addAttribute("page", "Products");
            model.addAttribute("title", "Menu");
//            List<ProductDto> products = productService.products();
//            model.addAttribute("products", products);

        return "index";
    }


    @GetMapping("/account")
    public String viewUserAccountForm( 
            @AuthenticationPrincipal CustomerDetails customerDetails,
            Model model) {
        String userEmail = customerDetails.getUsername();
         Customer customer= customerRepository.findByUsername(userEmail);

        model.addAttribute("customer", customer);
        model.addAttribute("pageTitle", "Account Details");

        return "account_form";
    }












}