package com.example.customer.Controller;


//import com.kidsart.library.model.Customer;
//import com.kidsart.library.model.ShoppingCart;
import com.example.library.dto.ProductDto;
import com.example.library.model.Category;
import com.example.library.model.Product;
import com.example.library.service.CategoryService;
import com.example.library.service.CustomerService;
import com.example.library.service.ProductService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final CustomerService customerService;
    @Autowired
    private ProductService productService;
    @Autowired
    private CategoryService categoryService;


    @RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
    public String home(Model model, Principal principal, HttpSession session) {
//        model.addAttribute("title", "Home");
//        model.addAttribute("page", "Home");
//        if (principal != null) {
//            Customer customer = customerService.findByUsername(principal.getName());
//            session.setAttribute("username", customer.getFirstName() + " " + customer.getLastName());
//            ShoppingCart shoppingCart = customer.getCart();
//            if (shoppingCart != null) {
//                session.setAttribute("totalItems", shoppingCart.getTotalItems());
//            }
//        }
        return "home";
    }

    @GetMapping
    public String index(Model model) {
        List<Category> categories = categoryService.findALl();
        List<Product> products = productService.findAll();
        model.addAttribute("categories",categories);
        model.addAttribute("products",products);
        //check ProductDto
        return "index";
    }

//    @GetMapping("/contact")
//    public String contact(Model model) {
//        model.addAttribute("title", "Contact");
//        model.addAttribute("page", "Contact");
//        return "contact-us";
//    }

}
