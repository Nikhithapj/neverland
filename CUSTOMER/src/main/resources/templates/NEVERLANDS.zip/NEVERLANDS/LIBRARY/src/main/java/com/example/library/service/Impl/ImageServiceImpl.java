package com.example.library.service.Impl;

import com.example.library.model.Image;
import com.example.library.service.ImageService;

import java.util.List;

public class ImageServiceImpl implements ImageService {
    @Override
    public List<Image> findProductImages() {
        return null;
    }

    @Override
    public List<Image> findAll() {
        return null;
    }
}
