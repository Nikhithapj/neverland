package com.example.library.service;

import com.example.library.dto.CustomerDto;
import com.example.library.model.Customer;

import java.util.List;

public interface CustomerService {
    Customer save(CustomerDto customerDto);

    Customer findByUsername(String username);

    Customer update(CustomerDto customerDto);
    List<CustomerDto> findAll();
    void blockUser(Long id);

    Customer changePass(CustomerDto customerDto);

    CustomerDto getCustomer(String username);
}
